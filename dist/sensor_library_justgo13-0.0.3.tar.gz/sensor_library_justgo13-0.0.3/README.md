Sensors project read me
=======================
Installation : 
1. Open command prompt
2. Enter  *pip install sensor_library*

Testing code:
Run *test.py* to test parser files

Sphinx Documentation
--------------------
[Learn sphinx documentation syntax](https://pythonhosted.org/an_example_pypi_project/sphinx.html)

Initialize project: *sphinx-quickstart* in **cmd** 

Document editor:  [Download Vim](https://www.vim.org/download.php#pc)

Build html page: *make html* using **cmd**